
from machine import Pin,PWM,ADC
from utime import sleep

LDR=ADC(28)
pwn = PWM(Pin(15))

pwn.freq(1000)

while True:
    value=LDR.read_u16()
    print(value)
    pwn.duty_u16(value)
    if value <5000:
        print("LOW")
        sleep(0.001)
    elif value >5000:
        print("better")
        sleep(0.001)


